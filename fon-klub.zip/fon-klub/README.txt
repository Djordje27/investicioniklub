Investicioni klub studenata FON-a, struktura sajta

index.html        sadržaj stranice
css/style.css     svi stilovi
js/main.js        sve animacije i interakcije (galerija, FAQ, meni, proces, knjiga)
assets/           slike i logo

U folder assets ubaci i ove fajlove (preimenuj ih tačno ovako):
  logo.svg               (ranije "image 5.svg")
  faq-coin.png           (ranije "Container (7).png")
  team-placeholder.jpg   (fotografija za tim, ili zameni po osobi u index.html)

Fotografije za galeriju stavi u assets/galerija/ i upiši putanje
u listu GALLERY na vrhu js/main.js (npr. "assets/galerija/01.jpg").
